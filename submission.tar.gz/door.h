/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=25x25 door door.jfif 
 * Time-stamp: Friday 04/03/2020, 21:39:25
 * 
 * Image Information
 * -----------------
 * door.jfif 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DOOR_H
#define DOOR_H

extern const unsigned short door[625];
#define DOOR_SIZE 1250
#define DOOR_LENGTH 625
#define DOOR_WIDTH 25
#define DOOR_HEIGHT 25

#endif

