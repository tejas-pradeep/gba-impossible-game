/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 L6 L_6_9.jpg 
 * Time-stamp: Tuesday 03/31/2020, 21:20:48
 * 
 * Image Information
 * -----------------
 * L_6_9.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef L6_H
#define L6_H

extern const unsigned short L_6_9[38400];
#define L_6_9_SIZE 76800
#define L_6_9_LENGTH 38400
#define L_6_9_WIDTH 240
#define L_6_9_HEIGHT 160

#endif

