/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 balck Black.png 
 * Time-stamp: Saturday 04/04/2020, 00:49:08
 * 
 * Image Information
 * -----------------
 * Black.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BALCK_H
#define BALCK_H

extern const unsigned short Black[38400];
#define BLACK_SIZE 76800
#define BLACK_LENGTH 38400
#define BLACK_WIDTH 240
#define BLACK_HEIGHT 160

#endif

