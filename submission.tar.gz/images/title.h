/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 title Title.png 
 * Time-stamp: Tuesday 03/31/2020, 21:12:49
 * 
 * Image Information
 * -----------------
 * Title.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLE_H
#define TITLE_H

extern const unsigned short Title[38400];
#define TITLE_SIZE 76800
#define TITLE_LENGTH 38400
#define TITLE_WIDTH 240
#define TITLE_HEIGHT 160

#endif

