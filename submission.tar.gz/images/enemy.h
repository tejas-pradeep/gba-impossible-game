/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=25x25 enemy enemy_image.png 
 * Time-stamp: Friday 04/03/2020, 21:47:13
 * 
 * Image Information
 * -----------------
 * enemy_image.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENEMY_H
#define ENEMY_H

extern const unsigned short enemy_image[625];
#define ENEMY_IMAGE_SIZE 1250
#define ENEMY_IMAGE_LENGTH 625
#define ENEMY_IMAGE_WIDTH 25
#define ENEMY_IMAGE_HEIGHT 25

#endif

