/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 loss loss.png 
 * Time-stamp: Wednesday 04/01/2020, 20:05:06
 * 
 * Image Information
 * -----------------
 * loss.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSS_H
#define LOSS_H

extern const unsigned short loss[38400];
#define LOSS_SIZE 76800
#define LOSS_LENGTH 38400
#define LOSS_WIDTH 240
#define LOSS_HEIGHT 160

#endif

