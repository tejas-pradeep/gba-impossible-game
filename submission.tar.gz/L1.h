/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 L1 L_1_5.jpg 
 * Time-stamp: Tuesday 03/31/2020, 21:20:33
 * 
 * Image Information
 * -----------------
 * L_1_5.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef L1_H
#define L1_H

extern const unsigned short L_1_5[38400];
#define L_1_5_SIZE 76800
#define L_1_5_LENGTH 38400
#define L_1_5_WIDTH 240
#define L_1_5_HEIGHT 160

#endif

