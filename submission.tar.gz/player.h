/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=25x25 player player_image.jpg 
 * Time-stamp: Wednesday 04/01/2020, 19:52:32
 * 
 * Image Information
 * -----------------
 * player_image.jpg 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYER_H
#define PLAYER_H

extern const unsigned short player_image[625];
#define PLAYER_IMAGE_SIZE 1250
#define PLAYER_IMAGE_LENGTH 625
#define PLAYER_IMAGE_WIDTH 25
#define PLAYER_IMAGE_HEIGHT 25

#endif

