/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 L10 L_10.jpg 
 * Time-stamp: Tuesday 03/31/2020, 21:21:14
 * 
 * Image Information
 * -----------------
 * L_10.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef L10_H
#define L10_H

extern const unsigned short L_10[38400];
#define L_10_SIZE 76800
#define L_10_LENGTH 38400
#define L_10_WIDTH 240
#define L_10_HEIGHT 160

#endif

